

// Ryan Sweitzer, Clint Meyer
// 3-16-17
// DoublyLinkedList & Node Classes

/**
*  @author Ryan Sweitzer
*  @author Clint Meyer 
*/
public class DoublyLinkedList <E> { // creating class for link list

// ------------nested node class--------------------------------
	private static class Node<E> { // creates node for information to go into
		private E element; // refers to element stored in this node
		private Node<E> next; // refers to next node in list
		private Node<E> prev; // refers to the previous node in list
/**		
* @param e  the element to be stored
* @param p  reference to a node that should precede the new node
* @param n  reference to a node that should follow the new node
*/		
		public Node(E e, Node<E> p, Node<E> n) {
			element = e;
			prev = p;
			next = n;
		}
		
		// default constructor
		public Node() {}
		
/**	@return the stored element */		
		public E getElement() { return element; }
/** @return the following node */
		public Node<E> getNext() { return next; }
/** @param n the node that should follow this one */
		public void setNext(Node<E> n) { next = n; }
/** @return the preceding node */
		public Node<E> getPrev() { return prev; }
/** @param p the node that should precede this one */
		public void setPrev(Node<E> p) { prev = p; }
	}

// ---------Start of DoublyLinkedList class-------------------------
	
	// instance variables of single link list
	private Node<E> head = null; // head node (null if empty)
	private Node<E> tail = null; // last node
	private int size = 0; // number of nodes
	
	public DoublyLinkedList() {
		head = new Node<>(null, null, null);
		tail = new Node<>(null, head, null);
		head.setNext(tail);
	}

	// access methods
/** @return returns size of list */
	public int size() { return size; }
/** @return returns zero if empty */
	public boolean isEmpty() { return size == 0; }
/** @return returns first element of list */
	public E first() { // returns (but does not remove) the first element
		if (isEmpty()) return null;
		return head.getNext().getElement();
	}
/** @return returns last element of list */
	public E last() {              // returns (but does not remove) the last element
		if (isEmpty()) return null;
		return tail.getPrev().getElement();
	}

	// update methods
/** @param e element to be added at head of list */
	
	public void addFirst(E e) {                // adds element e to the front of the list
		addBetween(e, head, head.getNext());
	}
	
/** @param e element to be added to tail of list */
	
	public void addLast(E e) {                 // adds element e to the end of the list
		addBetween(e, tail.getPrev(), tail);
	}

/** @return returns new head after removal of original head */
	
	public E removeFirst() {                   // removes and returns the first element
		if (isEmpty()) return null;              // nothing to remove
		return remove(head.getNext());
	}
	
	public E removeLast(){
		if(isEmpty()) return null;
		return remove(tail.getPrev());
	}

/**	
* @param e the element selected to be removed
* @return the removed element
* @throws IllegalArgumentException if e is not a valid element in the list
*/	
	private E remove(Node<E> node) throws IllegalArgumentException {// remove at position
	    Node<E> predecessor = node.getPrev();
	    Node<E> successor = node.getNext();
	    predecessor.setNext(successor);
	    successor.setPrev(predecessor);
	    size--;
	    return node.getElement();
	  }
/**	
* @param preddicessor node before location of where new element is inserted
* @param successor node after location of where new element is inserted
* @return new element's node
*/	
	private void addBetween(E e, Node<E> pred, Node<E> succ) { // add at a position
	    Node<E> newest = new Node<>(e, pred, succ);  // create and link a new node
	    pred.setNext(newest);
	    succ.setPrev(newest);
	    size++;
	}
	
/**
* @param e is element within list to retrieve
* @return element's index
*/
	public int getIndexOfElement(E e){
		Node<E> temp = head.getNext();
		int index = 0;
		if(isEmpty())
			return -1;
		while(!(temp.element).equals(e) && temp != null){
			temp = temp.next;
			index++;
		}
		return index;
	}
	
/**
* @param index is list index of desired position
* @param e is new element to replace with
*/
	public void replaceElementAt(int index, E e){
		Node<E> temp = head.next;
		if(index > size())
			return;
		for(int i = 0; i < index; i++){
			temp = temp.next;
		}
		temp.element = e;
	}
	
/**
* @param index is position within list to add
* @param e is element to add at given index
*/
	public void addAtIndex(int index, E e){
		Node<E> temp = head.next;
		
		if(index == size()-1){
			addLast(e);
			return;
		}
		else if(index == 0){
			addFirst(e);
			return;
		}
		
		for(int i = 0; i < index-1; i++){
			temp = temp.next;
		}
		
		Node<E> newNode = new Node<E>();
		newNode.element = e;
		newNode.next = temp.next;
		temp.next = newNode;
		size++;
	}
	
/** @param index is position within list to add */
	public void removeAtIndex(int index){
		Node<E> temp = head.next;
		
		if(index == size()-1){
			return;
		}
		else if(index == 0){
			removeFirst();
			return;
		}
		
		for(int i = 0; i < index -1; i++){
			temp = temp.next;
		}
		remove(temp.next);
		size--;
	}
	
	
/** @return returns string of contents of list */
	 public String toString() {  // print list
		    StringBuilder sb = new StringBuilder("(");
		    Node<E> walk = head.getNext();
		    while (walk != tail) {
		      sb.append(walk.getElement());
		      walk = walk.getNext();
		      if (walk != tail)
		        sb.append(", ");
		    }
		    sb.append(")");
		    return sb.toString();
	 }
}


