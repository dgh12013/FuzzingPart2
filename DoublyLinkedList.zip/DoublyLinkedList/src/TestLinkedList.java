import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class TestLinkedList{
	
	DoublyLinkedList list;
	
	@Before
	public void setUp() {
		list = new DoublyLinkedList();
		list.addFirst("Dylan"); 
		list.addLast("Roger"); 
		list.addAtIndex(2, "Hartman"); 
		list.replaceElementAt(2, "Garrett"); 
		list.removeAtIndex(1); 
	}
	
	@Test
	public void testAddFirst(){
		assertFalse(list.isEmpty()); //Make sure list was populated
		assertEquals("Dylan, Garrett should be current list.", "(Dylan, Garrett)", list.toString());
		assertEquals("Dylan should be first element", "Dylan", list.first());
	}

	@Test
	public void testReplaceElementAt(){
		assertFalse(list.isEmpty());
		assertEquals("Dylan, Garrett should be current list.", "(Dylan, Garrett)", list.toString());	
		assertEquals("Hartman should have been replaced with Garrett", 1, list.getIndexOfElement("Garrett"));
	}
}
